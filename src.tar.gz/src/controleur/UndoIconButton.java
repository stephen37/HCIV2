/**
 * 
 */
package controleur;

import javax.swing.JButton;

/**
 * @author stephen BATIFOL
 *
 */
public class UndoIconButton extends JButton {

}
