/**
 * 
 */
package controleur;

import javax.swing.JButton;

/**
 * @author stephen BATIFOL
 *
 */
public class ToolBoxIconButton extends JButton {

}
